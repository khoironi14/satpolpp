<!DOCTYPE html>
<html>
<head>
  <title>Informasi Pasar Kerja</title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css') ?>">
</head>
<body style="background-image:url(<?php echo base_url('assets/gambar/background.jpg') ?>)">

  


<div class="container">
<div class="menu_foto"><marquee><?php foreach ($berita as $tampil) {
 echo "<a href=''>".$tampil->judul."</a>";//$tampil->judul;
} ?></marquee> </div>
<div class="row">
<div class="col-md-12">

<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="<?php echo base_url('assets/slider/mou.jpg') ?>" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo base_url('assets/slider/mou.jpg') ?>" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo base_url('assets/slider/mou.jpg') ?>" alt="Third slide">
    </div>
  </div>
  </div>
  </div>
  <!--Content -->
<div class="col-md-12">
 <div class="breadcrumb mt-3"> <h5 align="center">Berita Tebaru</h5></div> 

<div class="card-group">
<?php foreach ($terkini as $tampil) {
   $isi=$tampil->isi;
     $limit=character_limiter($isi,200);
 ?>
 <div class="col-md-4">
  <div class="card">
    <img class="card-img-top" src='<?php echo base_url('assets/gambar_berita/'.$tampil->foto.'') ?>' alt="Card image cap">
    <div class="card-body">
      
     <h5 class="card-title"><a href='<?php echo base_url('Welcome/detail/'.$tampil->judul.'/'.$tampil->id.'') ?>'><?=$tampil->judul?></a></h5>
      <p class="card-text"><?=$limit?></p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Tanggal Terbit: <?=date('d-m-Y',strtotime($tampil->tgl_terbit))?></small>
    </div>
  </div>
  </div>
  <?php }?>
  
</div>

</div>



  </div>
  </div>
  </body>





 

</html>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.2.1.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.4/js/all.js"></script>
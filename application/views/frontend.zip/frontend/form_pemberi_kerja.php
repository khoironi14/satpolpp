<!DOCTYPE html>
<html>
<head>
	<title>Form Pemberi Kerja</title>
</head>
<body>
<div class="container">
<div class="col-md-6">
<form action="" method="">
<div><h4>Identitas Pemberi Kerja</h4></div>	
<label>Nama Pemberi Kerja</label>
<input type="text" name="nama_pemberi" class="form-control" required="">
<label>Lapangan Usaha</label>
<input type="text" name="lapangan_usaha">
<label>Alamat</label>
<textarea name="alamat" class="form-control" required=""></textarea>
<label>Telpon/HP</label>
<input type="text" name="hp_pemberi" class="form-control" required="">
<label>Email</label>
<input type="text" name="hp_pemberi" class="form-control">
<label>Kode Pos</label>
<input type="text" name="hp_pemberi" class="form-control">
<label>Kontak Person</label>
<input type="text" name="kontak" class="form-control">
<label>Jabatan</label>
<input type="text" name="jabatan" class="form-control">
</form>
</div>	
</div>
</body>
</html>
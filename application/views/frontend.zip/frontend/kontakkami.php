<!DOCTYPE html>
<html>
<head>
	<title>Kontak Kami</title>
</head>
<body style="background-image:url(<?php echo base_url('assets/gambar/background.jpg') ?>)">
<div class="container" style="background-color:white;">
<div class="menu_foto"><marquee><?php foreach ($berita as $tampil) {
 echo "<a href=''>".$tampil->judul."</a>";//$tampil->judul;
} ?></marquee> </div>
	<div class="col-md-12">
		
<h4>Kontak Kami</h4>
<p>Dinas Ketenagakerjaan <br> Kabupaten Cilacap, Jawa Tengah</p>
<p>Alamat: Jl.Perwira No 30 Sidanegara, Cilacap Tengah <br>Kabupaten Cilacap</p>
<p>Jawa Tengah</p>
<p>Telpon: 0282534005</p>
		
	</div>
</div>
</body>
</html>
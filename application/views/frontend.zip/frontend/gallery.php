<!DOCTYPE html>
<html>
<head>
	<title>Gallery</title>
</head>
<body style="background-image:url(<?php echo base_url('assets/gambar/background.jpg') ?>)">
<div class="container" style="background-color:white;">

<h4 class="alert alert-primary" style="margin-top:5px;"><img class="logo" style="max-width:70%;" src="<?php echo base_url('assets/gambar/satpol.png')?>"> Gallery Foto Kegiatan Satuan Polisi Pamong Praja</h4>
 


	<div class="col-md-12">

 
	<div class="card-group">
  <?php  foreach ($gallery as  $tampil) {
   
   ?>
   <div class="col-md-4">
  <div class="card">
 <button type="button" class="btn btn-primary foto" data-toggle="modal" data-target="#exampleModalCenter" id="<?=$tampil->id?>">
    <img class="card-img-top" style="max-width:100%;"  src="<?php echo base_url('assets/slider') ?>/<?php echo $tampil->foto ?>" alt="Card image cap"></button>
    <div class="card-body">
      <h5 class="card-title"><?=$tampil->judul?></h5>
      <p class="card-text"><?=$tampil->keterangan?></p>
     
    </div>
   
  </div>
  </div>
 
  <?php }?>
</div>

</div>
</div>


	</div>
  


</div>
</div>
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Foto</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="col-md-12" id="foto"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
</body>
</html>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.2.1.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
<script type="text/javascript">
  

$(document).ready(function(){
  $('.foto').click(function(){
    
var id=$(this).attr('id');
//alert(id);
$.ajax({
          
          url:"<?=site_url()?>Gallery/detail_foto",
          type:"POST",
          data:{id:id},
        
          
          success:function(data){
            $('#foto').html(data);
            
           
            //alert(data);
          }



          });
  })




  });



</script>

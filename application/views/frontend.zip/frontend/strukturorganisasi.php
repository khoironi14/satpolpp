<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-image:url(<?php echo base_url('assets/gambar/background.jpg') ?>)">
<div class="container">
<div class="row">
<div class="col-md-11">
<center>
<h2 class="alert alert-info" style="margin-top:6px;">Struktur Organisasi Dinas Ketenagakerjaan Kabupaten Cilacap</h2></center>
<img style="max-width:100%;" src="<?php echo base_url('assets/gambar/Struktur_Organisasi.jpg') ?>" class="img-responsive">	




</div>	





</div>	
</div>
</body>
</html>
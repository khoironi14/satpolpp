<!DOCTYPE html>
<html>
<head>
	<title>Informasi Pasar Kerja</title>
</head>
<body>
<div class="container">
	<div class="row">
	<div class="col-md-6">
		
<ul class="list-group list-group-flush">
  <li class="list-group-item"><p>Judul</p><p></p></li>
  <li class="list-group-item">Deskripsi</li>
  <li  class="list-group-item">Link Download</li>
 
</ul>

	</div>
		


	</div>
</div>
</body>
</html>
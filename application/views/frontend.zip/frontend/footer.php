
<footer>
<div class="col-md-12"  id="footer">
<div class="container-fluid">
<div class="row">

<div class="col-md-4" id="footer">

<h6 class="alert alert-success px-3 " >Kontak Kami</h6>	
<h6  class="px-3">Satuan Polisi Pamong Praja<br>Provinsi Sulawesi Selatan</h6>
<p class="px-3">Jl. Urip Sumoharjo No 269 Makasar
Telp: 0282534005 
</p>	


	</div>
<div class="col-md-4" id="footer">
<h6 class="alert alert-success px-3" >PartnerShip</h6>	
</div>
<div class="col-md-3" id="footer">
	

<h6 class="alert alert-success px-3">Stastik Pengunjung</h6>
<p>Hari ini:  <?=$stastik['jumlah']?></p>

<p>Hari ini:</p>
<p>Minggu ini</p>
<p>Bulan ini</p>
</div>

	</div>


	</div>


	</div>

</footer>

